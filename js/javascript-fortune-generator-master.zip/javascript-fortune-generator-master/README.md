A Fortune Cookie Generator page showing what one might expect in a fortune cookie. Built using Javascript and Photoshop.



